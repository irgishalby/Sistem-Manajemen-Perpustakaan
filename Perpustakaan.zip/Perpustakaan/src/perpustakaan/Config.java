package perpustakaan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Config {
    private static Connection mysqlconfig;

    public static Connection configDB() throws SQLException {
        try {
            String url = "jdbc:mysql://localhost:3306/perpus";
            String user = "root";
            String pass = "";
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            mysqlconfig = DriverManager.getConnection(url, user, pass);
            System.out.println("Database Connected");
        } catch (Exception e) {
            System.out.println("Koneksi gagal" + e.getMessage());
        }
        return mysqlconfig;
    }

    public static void main(String[] args) {
        try {
            configDB();
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
